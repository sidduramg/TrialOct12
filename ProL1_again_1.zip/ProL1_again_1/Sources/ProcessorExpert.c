/* ###################################################################
**     Filename    : ProcessorExpert.c
**     Project     : ProcessorExpert
**     Processor   : MKL25Z128VLK4
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2022-11-04, 14:12, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file ProcessorExpert.c
** @version 01.01
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup ProcessorExpert_module ProcessorExpert module documentation
**  @{
*/         
/* MODULE ProcessorExpert */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "FRTOS1.h"
#include "UTIL1.h"
#include "MCUC1.h"
#include "Led_main.h"
#include "BitsIoLdd1.h"
#include "seven_cc.h"
#include "BitsIoLdd2.h"
#include "seven_ca.h"
#include "BitsIoLdd3.h"
#include "Led_low.h"
#include "BitsIoLdd4.h"
#include "CsIO1.h"
#include "IO1.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"

SemaphoreHandle_t xSemaphore;

void Task2();
void Task3();
void Task1()
{
	printf("\nEntered into Task1 and Taking the resources into Task1\n");
	xSemaphoreTake(xSemaphore, portMAX_DELAY);
	printf("\nCreating Task2\n");
	xTaskCreate(Task2, "Task2", 100, NULL, 11, NULL);
	printf("\nRe-entered Task1 and Creating Task3\n");
	xTaskCreate(Task3, "Task3", 100, NULL, 12, NULL);
	//vTaskDelay(100/portTICK_PERIOD_MS);
	printf("\nRe-entered Task1\n");
	xSemaphoreGive(xSemaphore); 
	printf("\nExiting Task1\n");
	fflush(stdout);
	vTaskDelay(1000/portTICK_PERIOD_MS);
}

void Task2()
{
	printf("\nEntered into Task2\n");
	printf("\nExiting Task2\n");
	//printf("\nSetting a delay of 1600msec for Task2\n");
	vTaskDelay(10/portTICK_PERIOD_MS);
	printf("\nRe-entered Task2\n");
	printf("\nExiting Task2\n");
	fflush(stdout);
	//printf("\nResetting a delay of 1700msec for Task2\n");
	vTaskDelay(1000/portTICK_PERIOD_MS);
}

void Task3()
{
	printf("\nEntered into Task3\n");
	xSemaphoreTake(xSemaphore, portMAX_DELAY );
	xSemaphoreGive(xSemaphore);
	printf("\nTaking the resources into Task3\n");
	printf("\nExiting Task3\n");
	fflush(stdout);
	//printf("\nSetting a delay of 1500msec for Task3\n");
	vTaskDelay(1000/portTICK_PERIOD_MS);
}


int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */
  
  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/
  printf("Creating the Semaphore\n");
  printf("\nCreating the Task1\n");
  fflush(stdout);
  vSemaphoreCreateBinary(xSemaphore);
  xTaskCreate(Task1, "Task1", 100, NULL, 10, NULL);
  //xTaskCreate(Task2, "Task2", 100, NULL, 11, NULL);
  //xTaskCreate(Task3, "Task3", 100, NULL, 11, NULL);

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END ProcessorExpert */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.3 [05.08]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
